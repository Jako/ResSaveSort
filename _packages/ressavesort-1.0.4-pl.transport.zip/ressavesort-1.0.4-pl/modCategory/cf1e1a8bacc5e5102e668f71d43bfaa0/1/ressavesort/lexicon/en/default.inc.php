<?php
/**
 * Default Lexicon Entries for ResSaveSort
 *
 * @package ressavesort
 * @subpackage lexicon
 */

$_lang['ressavesort.sortby'] = 'Sort By';
$_lang['ressavesort.sortdir'] = 'Sort Dir';
$_lang['ressavesort.sortcontainer'] = 'Sort Container';
